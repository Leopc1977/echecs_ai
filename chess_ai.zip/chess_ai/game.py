from random import randint
from secrets import choice
from libs.utils import *

import pygame

class Game():
    def getPiecePng(s,x, y):
        realValuePiece = s.board[y][x]
        absValuePiece = abs(realValuePiece)
        path = "res/imgs/"
        namePiece = ""
        if absValuePiece == 5:
            namePiece = "rook"
        elif absValuePiece == 2:
            namePiece = "knight"
        elif absValuePiece == 3:
            namePiece = "bishop"
        elif absValuePiece == 9:
            namePiece = "king"
        elif absValuePiece == 500:
            namePiece = "queen"
        elif absValuePiece == 1:
            namePiece = "pawn"
        else:
            return None
        
        if realValuePiece < 0:
            namePiece = "black_" + namePiece
        else:
            namePiece = "white_" + namePiece
        return pygame.image.load(path + namePiece + ".png")

    def __init__(s,screen) -> None:
        #initialise les membres
        s.screen = screen
        s.isRunning = True

        s.blue = (90,137,181)
        s.white = (234,234,210)
        
        s.board = [
            #[-5,-2,-3,-500,-9,-3,-2,-5],
            #[-1,-1,-1,-1,-1,-1,-1,-1],
            #[0,0,0,0,0,0,0,0],
            #[0,0,0,0,0,0,0,0],

            #[0,0,0,0,0,0,0,0],
            #[0,0,0,0,0,0,0,0],
            #[1,1,1,1,1,1,1,1],
            #[5,2,3,500,9,3,2,5]

            [0,0,0,0,0,0,0,0],
            [0,0,0,0,0,0,0,0],
            [0,0,0,9,0,0,0,0],
            [0,0,0,0,0,0,0,0],

            [0,0,0,0,0,0,0,0],
            [0,0,0,0,0,0,0,0],
            [0,0,0,0,0,0,0,0],
            [0,0,0,0,0,0,0,0],
        ]
        s.boardImg = "res/colored_packed.png"
        s.turn = 1 #choice([-1,1])

        s.moves = getMovesKing(s.board,s.turn,3,2)

    def load(s):
        pygame.init()
        pygame.display.set_caption("Chess AI Battle")    

    #update the board
    def process(s):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                s.isRunning = False

    #draw the board
    def draw(s):
        s.screen.fill((255, 255, 255))
        isWhiteCase = True

        bishop = pygame.image.load("res/imgs/Sans titre.png").convert_alpha()
        for l in range(8):
            for c in range(8):
                #draw the board
                if isWhiteCase:
                    color = s.white
                    isWhiteCase = False
                else :
                    color = s.blue
                    isWhiteCase = True
                pygame.draw.rect(s.screen, color, (c*102,l*102,102,102))

                #draw the pieces
                pieceImage = s.getPiecePng(c,l)
                if pieceImage:
                    s.screen.blit(pieceImage, (c*102+5,l*102+5))

                if (c,l) in s.moves:
                    s.screen.blit(bishop, (c*102+5,l*102+5))
            isWhiteCase = not isWhiteCase

        pygame.display.flip()