def sign(x):
    if x > 0:
        return 1
    else:
        return -1

def getListPossibleMoves(board,player,x,y):
    # Get the piece
    piece = abs(board[y][x])
    # Get the possible moves
    moves = []
    if piece == 0:
        return moves
    # Get the possible moves
    if piece == 5:
        moves = getMovesRook(board,player,x,y)
    elif piece == 2:
        moves = getMovesKnight(board,player,x,y)
    elif piece == 3:    
        moves = getMovesBishop(board,player,x,y)
    elif piece == 9:
        moves = getMovesKing(board,player,x,y)
    elif piece == 500:
        moves = getMovesQueen(board,player,x,y)
    return moves 

def getMovesRook(board,player,x,y):
    ennemy = -player
    moves = []
    # Check the left
    for i in range(x-1,-1,-1):
        if abs(board[y][i]) == 0:
            moves.append((i,y))
        elif (board[y][i]/board[y][i]) == ennemy:
            moves.append((i,y))
            break
        else:
            break
    # Check the right
    for i in range(x+1,8):
        if abs(board[y][i]) == 0:
            moves.append((i,y))
        elif (board[y][i]/board[y][i]) == ennemy:
            moves.append((i,y))
            break
        else:
            break
    # Check the top
    for i in range(y-1,-1,-1):
        if (board[i][x]) == 0:
            moves.append((x,i))
        elif (board[i][x]/board[i][x]) == ennemy:
            moves.append((x,i))
            break
        else:
            break
    # Check the bottom
    for i in range(y+1,8):
        if abs(board[i][x]) == 0:
            moves.append((x,i))
        elif (board[i][x]/board[i][x]) == ennemy:
            moves.append((x,i))
            break
        else:
            break
    return moves

def getMovesKnight(board,player,x,y):
    ennemy = -player
    moves = []
    # Check the top left
    if x-1 >= 0 and y-2 >= 0:
        if (board[y-2][x-1]) == 0:
            moves.append((x-1,y-2))
        elif sign(board[y-2][x-1]) == ennemy:
            moves.append((x-1,y-2))
    # Check the top right
    if x+1 <= 7 and y-2 >= 0:
        if (board[y-2][x+1]) == 0:
            moves.append((x+1,y-2))
        elif sign(board[y-2][x+1]) == ennemy:
            moves.append((x+1,y-2))
    # Check the bottom left
    if x-1 >= 0 and y+2 <= 7:
        if (board[y+2][x-1]) == 0:
            moves.append((x-1,y+2))
        elif sign(board[y+2][x-1]) == ennemy:
            moves.append((x-1,y+2))
    # Check the bottom right
    if x+1 <= 7 and y+2 <= 7:
        if (board[y+2][x+1]) == 0:
            moves.append((x+1,y+2))
        elif sign(board[y+2][x+1]) == ennemy:
            moves.append((x+1,y+2))
    # Check the top left
    if x-2 >= 0 and y-1 >= 0:
        if (board[y-1][x-2]) == 0:
            moves.append((x+2,y-1))
        elif sign(board[y-1][x+2]) == ennemy:
            moves.append((y-1,x-2))
    # Check the top right
    if x+2 <= 7 and y-1 >= 0:
        print(board[y-1][x+2])
        if (board[y-1][x+2]) == 0:
            moves.append((x+2,y-1))
        elif sign(board[y-1][x+2]) == ennemy:
            moves.append((x+2,y-1))
    # Check the bottom left
    if x-2 >= 0 and y+1 <= 7:
        if (board[y+1][x-2]) == 0:
            moves.append((x-2,y+1))
        elif sign(board[y+1][x-2]) == ennemy:
            moves.append((x-2,y+1))
    # Check the bottom right
    if x+2 <= 7 and y+1 <= 7:
        if (board[y+1][x+2]) == 0:
            moves.append((x+2,y+1))
        elif sign(board[y+1][x+2]) == ennemy:
            moves.append((x+2,y+1))
    return moves

def getMovesBishop(board,player,x,y):
    ennemy = -player
    moves = []
    # Check the top left
    for i in range(1,8):
        if x-i >= 0 and y-i >= 0:
            if (board[y-i][x-i]) == 0:
                moves.append((x-i,y-i))
            elif sign(board[y-i][x-i]) == ennemy:
                moves.append((x-i,y-i))
                break
            else:
                break
    # Check the top right
    for i in range(1,8):
        if x+i <= 7 and y-i >= 0:
            if (board[y-i][x+i]) == 0:
                moves.append((x+i,y-i))
            elif sign(board[y-i][x+i]) == ennemy:
                moves.append((x+i,y-i))
                break
            else:
                break
    # Check the bottom left
    for i in range(1,8):
        if x-i >= 0 and y+i <= 7:
            if (board[y+i][x-i]) == 0:
                moves.append((x-i,y+i))
            elif sign(board[y+i][x-i]) == ennemy:
                moves.append((x-i,y+i))
                break
            else:
                break
    # Check the bottom right
    for i in range(1,8):
        if x+i <= 7 and y+i <= 7:
            if (board[y+i][x+i]) == 0:
                moves.append((x+i,y+i))
            elif sign(board[y+i][x+i]) == ennemy:
                moves.append((x+i,y+i))
                break
            else:
                break
    return moves
def getMovesQueen(board,player,x,y):
    moves = []
    moves = getMovesBishop(board,player,x,y)
    moves += getMovesRook(board,player,x,y)
    return moves

def getMovesKing(board,player,x,y):
    moves = []
    for l in range(3):
        for c in range(3):
            if l == 1 and c == 1:
                continue
            if x+l >= 0 and x+l <= 7 and y+c >= 0 and y+c <= 7:
                if (board[y+c-1][x+l-1]) == 0:
                    moves.append((x+l-1,y+c-1))
                elif sign(board[y+c-1][x+l-1]) == -player:
                    moves.append((x+l-1,y+c-1))
    return moves