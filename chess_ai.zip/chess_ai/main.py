from game import Game
import pygame

isRunning = True

screen = pygame.display.set_mode((102*8,102*8))

game = Game(screen)

game.load()

while isRunning: 
    game.process()
    game.draw()
    isRunning = game.isRunning

pygame.quit()
print("finished")